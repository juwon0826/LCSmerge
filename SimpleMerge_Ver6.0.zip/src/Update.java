import java.awt.Color;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;
import java.util.LinkedList;

import javax.swing.JTextArea;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Highlighter;
import javax.swing.text.DefaultHighlighter.DefaultHighlightPainter;

public class Update {
	private JTextArea textArea = null;
	private LinkedList<Node> list = null;
	
	private DefaultHighlightPainter redPainter = new DefaultHighlighter.DefaultHighlightPainter(Color.RED);
	private DefaultHighlightPainter yellowPainter = new DefaultHighlighter.DefaultHighlightPainter(Color.YELLOW);
    private DefaultHighlightPainter grayPainter = new DefaultHighlighter.DefaultHighlightPainter(Color.GRAY);
	
	Update(LinkedList<Node> list, JTextArea textArea) {
		this.list = list;
		this.textArea = textArea;
		//textArea.setSelectionColor(Color.GREEN);
	}
	
	void setInfo(LinkedList<Node> list, JTextArea textArea) {
		this.list = list;
		this.textArea = textArea;
	}
	
	LinkedList<Node> areaToList() {
		// textArea strings move to list
		LinkedList<Node> list = new LinkedList<Node>();

		StringReader strings = new StringReader(textArea.getText());
		BufferedReader allString = new BufferedReader(strings);
		String oneLine = null;
		
		Highlighter.Highlight[] highlight = textArea.getHighlighter().getHighlights();
		int index = 0;
		
		try {
			while((oneLine = allString.readLine()) != null) {
				Node oneLineNode = new Node();
				oneLineNode.setString(oneLine);
				
				int lineLen = oneLineNode.getString().length() + 1;
				int highlightLen = 0;
				
				if(highlight.length != 0) {
					while(true) {
						if(index >= highlight.length) {
							break;
						}
						
						int start = highlight[index].getStartOffset();
						int end = highlight[index].getEndOffset();
						
						int tempLen = (end - start);
						highlightLen += tempLen;
						
						if(lineLen == highlightLen) {
							if(highlight[index].getPainter().toString() == grayPainter.toString()) {
								oneLineNode.setIsAddedenter(true);
							}
							
							index++;
							break;
						}
						
						index++;
					}
					
					
				}
				
				list.add(oneLineNode);
			}
		} catch(IOException e) {
			System.out.println("Error : IOException");
			return null;
		}
		
		return list;
	}
	
	void listToArea(boolean isInit) {
		// print list to area
		
		if(list == null) {
			return;
		}
		
		textArea.setText("");
		
	    Highlighter hi = new MyHighlighter();
		//Highlighter hi = new DefaultHighlighter();
		textArea.setHighlighter(hi);
	    
		int start = 0;
        int end = 0 ;
        int[] stringIndex ;
        int tempIndex = 0;
        
        if(list.get(0).getString() == "\n") {
        	list.get(0).setString("");	
        }
        
        textArea.append(list.get(0).getString() + "\n");
		
		for(int i = 0; i < list.size(); i++) {
			if((i + 1) < list.size()) {
				
				if(list.get(i+ 1).getString() == "\n") {
					list.get(i + 1).setString("");
		        }
				
				textArea.append(list.get(i + 1).getString() + "\n");
			}
			
		    try {
		        //look for newline char, and then toggle between white and gray painters.
		        end = start  + list.get(i).getString().length();
	            
	            if(list.get(i).getIsAddedEnter() == true) {
	            	hi.addHighlight(start, end + 1, grayPainter);
	            }
	            
	            else if(list.get(i).getIsLCS() == true) {
	            	hi.addHighlight(start, end + 1, yellowPainter);
	            }
	            
	            else {
	            	if(isInit == false) {
	            		for(int j = 0; j < (end - start); j ++){
		            		stringIndex = list.get(i).getString_index();
		            		if(stringIndex == null) break;
		            		
		            		else if(j == stringIndex[tempIndex] && stringIndex[tempIndex] >= 0){
		            			if(j == (end - start - 1)) { 
		            				hi.addHighlight(start + j, start + j + 2, yellowPainter);
		            			}
		            			
		            			else {
		            				hi.addHighlight(start + j, start + j + 1, yellowPainter);
		            			}
		            			
		            			tempIndex++;
		            			
		            			if(stringIndex[tempIndex] < 0) {
		            				continue;
		            			}
		            		}
		            		
		            		else {
		            			if(j == (end - start -1)) {
		            				hi.addHighlight(start + j, start + j + 2, redPainter);
		            			}
		            			
		            			else {
		            				hi.addHighlight(start + j, start + j + 1, redPainter);
		            			}
		            		}
		            	}
	            		
	            		tempIndex = 0;
	            	}
	            }
	            
		        start = end+1;	
		        
		    } catch (BadLocationException e) {
		        e.printStackTrace();
		    }
		}
	}
}
