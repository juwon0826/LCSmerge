import java.util.LinkedList;
 
public class Merge {		
	public void merge(LinkedList<Node> node1, LinkedList<Node> node2, int start, int end){	
		for(int i = start; i < end; i++){
			if(node1.get(i).getIsLCS() == false){
				node1.get(i).setIsLCS(true);
				node2.get(i).setIsLCS(true);
				node2.get(i).setString(node1.get(i).getString());
			}
			
			node1.get(i).setIsAddedenter(false);
			node2.get(i).setIsAddedenter(false);
		}
	}
 
}