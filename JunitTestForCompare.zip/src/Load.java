

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;

import javax.swing.JFileChooser;


public class Load extends FileManager{
	
	public Load() {														// initialize
		chooser = new JFileChooser();
		chooser.setDialogTitle("load");
	}

	public void fileTask(LinkedList<Node> textList) {
		if(fileName == null) {
			return;
		}
		
		try {
			
			
			BufferedReader in = new BufferedReader(new FileReader(fileName));
			String oneLine = null;
			
			
			while((oneLine = in.readLine()) != null) {							// read each line until EOF
				Node oneLineNode = new Node();
				oneLineNode.setString(oneLine);
				
				textList.add(oneLineNode);
			}
			
			in.close();
			
			
			
		} catch(IOException e) {
			fileName = null;
			System.out.println("Error : IOException");
		}
		
	}
	
}
