

import java.io.File;
import java.util.LinkedList;

import javax.swing.JFileChooser;


public abstract class FileManager {
	protected File fileName = null;
	protected JFileChooser chooser;
	
	public abstract void fileTask(LinkedList<Node> textList);
	
	public void openPopup(){
		int returnValue = chooser.showOpenDialog(null);
		
		if(returnValue == JFileChooser.APPROVE_OPTION) {
			fileName = chooser.getSelectedFile();
		}
		
		else {
			fileName = null;
			System.out.println("Cancel File Select");
		}
	}

}
