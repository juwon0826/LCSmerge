import static org.junit.Assert.*;

import java.util.LinkedList;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import static org.easymock.EasyMock.aryEq;
import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.expectLastCall;
import static org.easymock.EasyMock.replay;
import static org.easymock.EasyMock.verify;

public class ComparatorTest {
	
	LinkedList<Node> L1, L2;
	Node N1, N2;
	Node testN1,testN2;
	LCS lcsChecker;
	Comparator comparator;
	FileManager fileManager;
	
	@Before
	public void setUp() throws Exception{
		comparator = new Comparator();
		N1.setString("It's String compare test");
		N2.setString("It's compare String test");
		L1.add(N1);
		testN1.setString("It's String compare test");
		testN2.setString("It's String compare test");
		N1.getString_index()
		
		
		
	}
	
	@Test
	public void compareStringTest(){
		comparator.compareString(N1, N2);
		
	}

}
