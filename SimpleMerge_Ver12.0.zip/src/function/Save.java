package function;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedList;

import javax.swing.JFileChooser;

import model.Node;

public class Save extends FileManager{
	
	public Save() {							// initialize
		chooser = new JFileChooser();
		chooser.setDialogTitle("save");
		chooser.setApproveButtonText("����");
	}
	
	public void fileTask(LinkedList<Node> textList) {
		if(fileName == null) {
			return;
		}
		
		try {
			BufferedWriter out = new BufferedWriter(new FileWriter(fileName));
			
			for(int i = 0; i < textList.size(); i++) {								// write file until EOF
				if(textList.get(i).getIsAddedEnter()) {									// if boolean enter is true, continue
					continue;
				}
				
				out.write(textList.get(i).getString());								// write oneLine to file
				out.newLine();														// make newLine
			}
			
			out.close();
		} catch(IOException e) {
			fileName = null;
			textList = null;
			System.out.println("Error : IOException");
		}
	}
	
}
