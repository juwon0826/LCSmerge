import java.util.LinkedList;
 
public class Merge {
	public void merge(LinkedList<Node> list1, LinkedList<Node> list2, int start, int end){
		for(int i = start; i <= end; i++){
			if(i >= list1.size()) {
				break;
			}
			
			if(list1.get(i).getIsLCS() == false){
				list1.get(i).setIsLCS(true);
				list2.get(i).setIsLCS(true);
				list2.get(i).setString(list1.get(i).getString());
				
				if(list2.get(i).getIsAddedEnter() == true) {
					list2.get(i).setIsAddedenter(false);
				}
			}
		}
	}
}