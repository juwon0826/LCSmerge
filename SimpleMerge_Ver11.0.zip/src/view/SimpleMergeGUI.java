package view;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;


import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JButton;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;
import java.util.LinkedList;
import javax.swing.JScrollPane;

public class SimpleMergeGUI extends JFrame {
   JButton leftMergeButton;
   JButton rightMergeButton;

   JButton lFileLoadButton;
   JButton lFileSaveButton;
   JButton lFileEditButton;

   JButton rFileLoadButton;
   JButton rFileSaveButton;
   JButton rFileEditButton;

   JButton compareButton;
   
   JTextArea lTextArea;
   JTextArea rTextArea;

   private JPanel contentPane;
   
   public JTextArea getlTextArea(){
	 return lTextArea;  
   };
   public JTextArea getrTextArea(){
	 return rTextArea;  
   };
    public JButton getleftMergeButton(){
       return leftMergeButton;
    };
    public JButton getrightMergeButton(){
       return rightMergeButton;
    };
 
    public JButton getlFileLoadButton(){
       return lFileLoadButton;
    };
    public JButton getlFileSaveButton(){
       return lFileSaveButton;
    };
    public JButton getlFileEditButton(){
       return lFileEditButton;
    };

    public JButton getrFileLoadButton(){
       return rFileLoadButton;
    };
    public JButton getrFileSaveButton(){
       return rFileSaveButton;
       };
    public JButton getrFileEditButton(){
       return rFileEditButton;
    };
    public JButton getCompareButton(){
    	return this.compareButton;
    };
 
    public void setleftMergeButton(JButton setitem){
        this. leftMergeButton= setitem;
    };
    public void setrightMergeButton(JButton setitem){
          this. rightMergeButton= setitem;
    };

    public void setlFileLoadButton(JButton setitem){
          this. lFileLoadButton= setitem;
    };
    public void setlFileSaveButton(JButton setitem){
          this. lFileSaveButton= setitem;
    };
    public void setlFileEditButton(JButton setitem){
          this. lFileEditButton= setitem;
    };

    public void setrFileLoadButton(JButton setitem){
          this. rFileLoadButton= setitem;
    };
    public void setrFileSaveButton(JButton setitem){
          this. rFileSaveButton= setitem;
    };
    public void setrFileEditButton(JButton setitem){
          this. rFileEditButton= setitem;
    };
    public void setCompareButton(JButton setitem){
    	  this.compareButton = setitem;
    };
    public void setlTextArea(JTextArea setitem){
    	this.lTextArea = setitem;
    };
    public void setrTextArea(JTextArea setitem){
    	this.rTextArea = setitem;
    };
             
   public SimpleMergeGUI() {
      // create frame
      setBackground(Color.WHITE);
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      setBounds(100, 100, 1500, 900);
   
      contentPane = new JPanel();
      contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
      contentPane.setLayout(new BorderLayout(0, 0));
      setContentPane(contentPane);

      // create file manager panel
      JPanel fileManagerPanel = new JPanel();
      contentPane.add(fileManagerPanel, BorderLayout.NORTH);
      fileManagerPanel.setLayout(new GridLayout(0, 3, 0, 0));
      // ���� ���� left,edit,save�� ��� panel
      JPanel lFilePanel = new JPanel();
      fileManagerPanel.add(lFilePanel);
      lFilePanel.setLayout(new GridLayout(0, 3, 0, 0));
      // ��� panel
      JPanel titlePanel = new JPanel();
      fileManagerPanel.add(titlePanel);
      titlePanel.setLayout(new GridLayout(0, 3, 0, 0));
      // ������ ���� left,edit,save�� ��� panel
      JPanel rFilePanel = new JPanel();
      fileManagerPanel.add(rFilePanel);
      rFilePanel.setLayout(new GridLayout(0, 3, 0, 0));

      // create text area panel
      JPanel textAreaPanel = new JPanel();
      contentPane.add(textAreaPanel, BorderLayout.CENTER);
      textAreaPanel.setLayout(new GridLayout(1,2));
      // create left text area
      this.lTextArea = new JTextArea();
      textAreaPanel.add(lTextArea);
      lTextArea.setEditable(false);
      // create right text area
      this.rTextArea = new JTextArea();
      textAreaPanel.add(rTextArea);
      rTextArea.setEditable(false);

      // left file load
      this.lFileLoadButton = new JButton("load");
      
      lFilePanel.add(lFileLoadButton);
   
      // left file edit
      this.lFileEditButton = new JButton("edit");
      lFilePanel.add(lFileEditButton);
      
      JScrollPane scrollPane = new JScrollPane(lTextArea);
      scrollPane
            .setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
      scrollPane
            .setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
      
      
      
      getContentPane().add(BorderLayout.CENTER, textAreaPanel);
      // left file save
      this.lFileSaveButton = new JButton("save");
      lFilePanel.add(lFileSaveButton);
      lFileSaveButton.setEnabled(false);
      // right file load
      this.rFileLoadButton = new JButton("load");
      rFilePanel.add(rFileLoadButton);
   
      // right file edit
      this.rFileEditButton = new JButton("edit");
      rFilePanel.add(rFileEditButton);
      
      JPanel bottomPanel = new JPanel(new GridLayout(0, 2, 0, 0));   //Do it
      TextLineNumber tln = new TextLineNumber(lTextArea);
      scrollPane.setRowHeaderView( tln );
      JTextField status = new JTextField();
      lTextArea.addCaretListener(new CaretListener(){

         @Override
         public void caretUpdate(CaretEvent arg0) {
            JTextArea editArea = (JTextArea)arg0.getSource();
            int linenum =1;
            int columnnum = 1;
            
            try{
               int caretpos = editArea.getCaretPosition();
               linenum = editArea.getLineOfOffset(caretpos);
               columnnum = caretpos - editArea.getLineStartOffset(linenum);
               linenum += 1;
            }
            catch(Exception ex){}
            status.setText("Line: " + linenum + " Column: " + columnnum);
         
         }   
      });
         
       bottomPanel.add(status);
   
      JScrollPane scrollPane2 = new JScrollPane(rTextArea);
      scrollPane2
            .setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
      scrollPane2
            .setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
      getContentPane().add(BorderLayout.CENTER, textAreaPanel);
      
      TextLineNumber tln2 = new TextLineNumber(rTextArea);
      scrollPane2.setRowHeaderView( tln2 );
      
      JTextField status2 = new JTextField();
      rTextArea.addCaretListener(new CaretListener(){

         @Override
         public void caretUpdate(CaretEvent arg0) {
            JTextArea editArea = (JTextArea)arg0.getSource();
            int linenum =1;
            int columnnum = 1;
            
            try{
               int caretpos = editArea.getCaretPosition();
               linenum = editArea.getLineOfOffset(caretpos);
               columnnum = caretpos - editArea.getLineStartOffset(linenum);
               linenum += 1;
            }
            catch(Exception ex){}
            status2.setText("Line: " + linenum + " Column: " + columnnum);
         
         }   
      });
      
      bottomPanel.add(status2);
      add(bottomPanel, BorderLayout.SOUTH);
      // right file save
      this.rFileSaveButton = new JButton("save");
      rFilePanel.add(rFileSaveButton);
      rFileSaveButton.setEnabled(false);
   

      textAreaPanel.add(scrollPane);
      // create center button (compare & merge)
      this.compareButton = new JButton("compare");
      compareButton.setEnabled(false);
      // create merge panel

      this.leftMergeButton = new JButton("��=");
      leftMergeButton.setEnabled(false);
      // merge left to right
      this.rightMergeButton = new JButton("=��");
      rightMergeButton.setEnabled(false);
      
      titlePanel.add(leftMergeButton);
      titlePanel.add(compareButton);
      titlePanel.add(rightMergeButton);
      textAreaPanel.add(scrollPane2);
      
      
   }
}