package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;

import function.Comparator;
import function.EnterSync;
import function.Load;
import function.Merge;
import function.Save;
import function.Update;
import model.Node;
import view.SimpleMergeGUI;

public class MergeController {
	static boolean edit1 = false;
	static boolean edit2 = false;
	LinkedList<Node> lFileList = null;
	LinkedList<Node> rFileList = null;
	Update update;
	SimpleMergeGUI gui;
	
	public MergeController(){
		this.update = new Update();
		gui = new SimpleMergeGUI();
	}
	
	public SimpleMergeGUI getGUI(){
		return this.gui;
	}
	public void setGUI(SimpleMergeGUI setitem){
		this.gui = setitem;
	}
	
	public void control(){
		
		
		
		gui.getleftMergeButton().addActionListener(new ActionListener() {
			int start, end;
			public void actionPerformed(ActionEvent e) {
				try {
					start = gui.getrTextArea().getLineOfOffset(gui.getrTextArea()
							.getSelectionStart());
					end = gui.getrTextArea().getLineOfOffset(gui.getrTextArea().getSelectionEnd());
				} catch (Exception ex) {}
			
				lFileList = update.areaToList(gui.getlTextArea());
				rFileList = update.areaToList(gui.getrTextArea());
				
				Merge merge = new Merge();
				merge.merge(rFileList, lFileList, start, end);
				
				Comparator comparator = new Comparator();
				EnterSync enterSyncer = new EnterSync();
				
				comparator.compareList(lFileList, rFileList);
				enterSyncer.enterSync(lFileList, rFileList);
				comparator.compareString(lFileList, rFileList);
				
				update.listToArea(false,lFileList,gui.getlTextArea());
				update.listToArea(false,rFileList,gui.getrTextArea());
			}
		});
		gui.getrightMergeButton().addActionListener(new ActionListener() {
			int start, end;
			public void actionPerformed(ActionEvent e) {
				try {
					start = gui.getlTextArea().getLineOfOffset(gui.getlTextArea().getSelectionStart());
					end = gui.getlTextArea().getLineOfOffset(gui.getlTextArea().getSelectionEnd());
				} catch (Exception ex) {}
				
				lFileList = update.areaToList(gui.getlTextArea());
				rFileList = update.areaToList(gui.getrTextArea());
				
				Merge merge = new Merge();
				merge.merge(lFileList, rFileList, start, end);
				
				Comparator comparator = new Comparator();
				EnterSync enterSyncer = new EnterSync();
				
				comparator.compareList(lFileList, rFileList);
				enterSyncer.enterSync(lFileList, rFileList);
				comparator.compareString(lFileList, rFileList);

			
				update.listToArea(false,lFileList,gui.getlTextArea());
				update.listToArea(false,rFileList,gui.getrTextArea());
			}
		});
		gui.getlFileLoadButton().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Load load = new Load();
				load.openPopup();
				load.loadFromFile();
				lFileList = load.getList();
				
				update.listToArea(true,lFileList,gui.getlTextArea());
				
				if(lFileList != null ) {
					gui.getlFileSaveButton().setEnabled(true);
					
					if(rFileList != null) {
						gui.getCompareButton().setEnabled(true);
					}
				}
			}
		});
		gui.getlFileSaveButton().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				lFileList = update.areaToList(gui.getlTextArea());
				
				Save save = new Save(lFileList);
				save.openPopup();
				save.saveToFile();
			}
		});
		
		gui.getlFileEditButton().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				edit1 = !edit1;
				gui.getlTextArea().setEditable(edit1);
				gui.getlFileSaveButton().setEnabled(true);
				
				if(edit2 == true && edit1 ==true){
	            	gui.getCompareButton().setEnabled(true);
	            }
				
				if(edit1 == true) {
					gui.getleftMergeButton().setEnabled(false);
					gui.getrightMergeButton().setEnabled(false);
				}
			}
		});
		gui.getrFileLoadButton().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Load load = new Load();
				load.openPopup();
				load.loadFromFile();
				rFileList = load.getList();
				
				update.listToArea(true,rFileList,gui.getrTextArea());
				
				if( rFileList != null) {
					gui.getrFileSaveButton().setEnabled(true);
					if(lFileList != null) {
						gui.getCompareButton().setEnabled(true);
					}
				}
			}
		});
		
		gui.getrFileEditButton().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				edit2 = !edit2;
				gui.getrTextArea().setEditable(edit2);
				gui.getrFileSaveButton().setEnabled(true);
	            
				if(edit2 == true && edit1 ==true){
	            	gui.getCompareButton().setEnabled(true);
	            }
				
				if(edit2 == true) {
					gui.getleftMergeButton().setEnabled(false);
					gui.getrightMergeButton().setEnabled(false);
				}
			}
		});
	
		gui.getrFileSaveButton().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				rFileList = update.areaToList(gui.getrTextArea());
				
				Save save = new Save(rFileList);
				save.openPopup();
				save.saveToFile();
				
			}
		});
	
		gui.getCompareButton().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				lFileList = update.areaToList(gui.getlTextArea());
				rFileList = update.areaToList(gui.getrTextArea());
				
				
				Comparator comparator = new Comparator();
				EnterSync enterSyncer = new EnterSync();
				
				comparator.compareList(lFileList, rFileList);
				enterSyncer.enterSync(lFileList, rFileList);
				comparator.compareString(lFileList, rFileList);

				
				update.listToArea(false,lFileList,gui.getlTextArea());
				update.listToArea(false,rFileList,gui.getrTextArea());
				
				gui.getrightMergeButton().setEnabled(true);
	            gui.getleftMergeButton().setEnabled(true);
	            
	            edit1 = false;
	            edit2 = false;
	            
	            gui.getlTextArea().setEditable(edit1);
	            gui.getrTextArea().setEditable(edit2);
			}
		});

	
		
	}
	
	
	
}
