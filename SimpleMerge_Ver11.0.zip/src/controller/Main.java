package controller;

import java.awt.EventQueue;

public class Main {
	public static void main(String[] args) {
		
		  EventQueue.invokeLater(new Runnable() {
		   public void run() {
		    try {
		    	MergeController controller = new MergeController();
		     controller.getGUI().setVisible(true);
		     controller.control();
		    } catch (Exception e) {
		     e.printStackTrace();
		    }
		   }
		  });
		 }
}
