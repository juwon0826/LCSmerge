import java.awt.Color;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;
import java.util.LinkedList;

import javax.swing.JTextArea;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Highlighter;
import javax.swing.text.DefaultHighlighter.DefaultHighlightPainter;

public class Update {
	private DefaultHighlightPainter redPainter = new DefaultHighlighter.DefaultHighlightPainter(Color.RED);
	private DefaultHighlightPainter yellowPainter = new DefaultHighlighter.DefaultHighlightPainter(Color.YELLOW);
    private DefaultHighlightPainter grayPainter = new DefaultHighlighter.DefaultHighlightPainter(Color.GRAY);
    //private DefaultHighlightPainter greenPainter = new DefaultHighlighter.DefaultHighlightPainter(Color.GREEN);
	
	LinkedList<Node> areaToList(JTextArea textArea) {
		LinkedList<Node> list = new LinkedList<Node>();
		StringReader strings = new StringReader(textArea.getText());
		BufferedReader allString = new BufferedReader(strings);
		String oneLine = null;
		
		Highlighter.Highlight[] highlight = textArea.getHighlighter().getHighlights();
		int index = 0;
		int lineLen = 0;
		int oneLineLen = 0;
		
		try {
			while((oneLine = allString.readLine()) != null) {
				Node oneLineNode = new Node();
				oneLineNode.setString(oneLine);
				
				oneLineLen = oneLineNode.getString().length() + 1;
				int highlightLen = 0;
				
				if(highlight.length != 0) {
					while(true) {
						if(index >= highlight.length) {
							break;
						}
						
						int start = highlight[index].getStartOffset();
						int end = highlight[index].getEndOffset();
						
						/*
						int tempLen = (end - start);
						highlightLen += tempLen;
						
						if(oneLineLen == highlightLen) {
							if(highlight[index].getPainter().toString() == grayPainter.toString()) {
								oneLineNode.setIsAddedenter(true);
							}
							
							index++;
							break;
						}
						
						index++;
						
						*/
						
						if(lineLen != start) {
							lineLen += oneLineLen;
							break;
						}
						
						int tempLen = (end - start);
						
						if(highlight[index].getPainter().toString().equals(grayPainter.toString())) {
							oneLineNode.setIsAddedenter(true);
							highlightLen++;
						}
						
						else if(highlight[index].getPainter().toString().equals(yellowPainter.toString())) {
							highlightLen += tempLen;
						}
						
						else {
							highlightLen += tempLen;
						}
						
						index++;
						lineLen += tempLen;
						
						if(oneLineLen == highlightLen) {
							break;
						}
					}
				}
				
				list.add(oneLineNode);
			}
			
		} catch(IOException e) {
			System.out.println("Error : IOException");
			return null;
		}
		
		return list;
	}
	
	void listToArea(boolean isInit, LinkedList<Node> list, JTextArea textArea) {
		// print list to area
		
		if(list == null) {
			return;
		}
		
		textArea.setText("");
		
	    Highlighter hi = new DefaultHighlighter();
		textArea.setHighlighter(hi);
	    
		DefaultHighlighter highlighter = (DefaultHighlighter) textArea.getHighlighter();
        highlighter.setDrawsLayeredHighlights(false);
        
		int start = 0;
        int end = 0 ;
        int[] stringIndex ;
        int tempIndex = 0;
        
        if(list.get(0).getString() == "\n") {
        	list.get(0).setString("");	
        }
        
        if(list.get(0).getString() != null) {
        	textArea.append(list.get(0).getString() + "\n");	
        }
		
		for(int i = 0; i < list.size(); i++) {
			if((i + 1) < list.size()) {
				if(list.get(i+ 1).getString() == "\n") {
					list.get(i + 1).setString("");
		        }
				
				if(list.get(i + 1).getString() != null) {
					textArea.append(list.get(i + 1).getString() + "\n");
				}
			}
			
		    try {
		        //look for newline char, and then toggle between white and gray painters.
		        end = start  + list.get(i).getString().length();
	            
	            if(list.get(i).getIsAddedEnter() == true) {
	            	hi.addHighlight(start, end + 1, grayPainter);
	            }
	            
	            else if(list.get(i).getIsLCS() == true) {
	            	//hi.addHighlight(start, end + 1, greenPainter);
	            }
	            
	            else {
	            	if(isInit == false) {
	            		for(int j = 0; j < (end - start); j ++){
		            		stringIndex = list.get(i).getString_index();
		            		if(stringIndex == null) break;
		            		
		            		else if(j == stringIndex[tempIndex] && stringIndex[tempIndex] >= 0){
		            			if(j == (end - start - 1)) { 
		            				hi.addHighlight(start + j, start + j + 2, yellowPainter);
		            			}
		            			
		            			else {
		            				hi.addHighlight(start + j, start + j + 1, yellowPainter);
		            			}
		            			
		            			tempIndex++;
		            			
		            			if(stringIndex[tempIndex] < 0) {
		            				continue;
		            			}
		            		}
		            		
		            		else {
		            			if(j == (end - start -1)) {
		            				hi.addHighlight(start + j, start + j + 2, redPainter);
		            			}
		            			
		            			else {
		            				hi.addHighlight(start + j, start + j + 1, redPainter);
		            			}
		            		}
		            	}
	            		
	            		tempIndex = 0;
	            	}
	            }
	            
		        start = end+1;	
		        
		    } catch (BadLocationException e) {
		        e.printStackTrace();
		    }
		}
	}
}
