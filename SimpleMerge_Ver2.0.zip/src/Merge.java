import java.util.LinkedList;
 
public class Merge {		
	public void merge(LinkedList<Node> node1, LinkedList<Node> node2, int start, int end){	
		for(int i = start; i < end + 1; i++){
			
			if(node1.get(i) == null || node2.get(i) == null)
				System.out.println("Fuck");
			else
				node2.get(i).setString(node1.get(i).getString());
			
		}
	}
 
}