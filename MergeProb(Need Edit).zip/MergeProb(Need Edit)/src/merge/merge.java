package merge;

import java.util.LinkedList;

public class merge {	
	public void copytoright(LinkedList<Node> node1, LinkedList<Node> node2){
		int length = node1.size();		
		for(int i = 0; i < length; i++){
			if(!(node1.get(i).getIsLCS())){
				node2.get(i).setString(node1.get(i).getString());
				node2.get(i).setIsAddedenter(false);
			}
		}
	}
	public void copytoleft(LinkedList<Node> node1, LinkedList<Node> node2){
		int length = node1.size();		
		for(int i = 0; i < length; i++){
			if(!(node2.get(i).getIsLCS())){
				node1.get(i).setString(node2.get(i).getString());
				node1.get(i).setIsAddedenter(false);
				
			}
		}
	}
 
}